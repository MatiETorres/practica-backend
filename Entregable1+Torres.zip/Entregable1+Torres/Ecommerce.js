class Prenda {
    constructor(nombre, precio, stock) {
      this.nombre = nombre;
      this.precio = precio;
      this.stock = stock;
    }
  
    verificarStock() {
      return this.stock > 0;
    }
  }
  
  class Carrito {
    constructor() {
      this.prendas = [];
    }
  
    agregarPrenda(prenda) {
      if (prenda.verificarStock()) {
        this.prendas.push(prenda);
        prenda.stock--;  
        alert(`${prenda.nombre} agregado al carrito.`);
      } else {
        alert(`No hay stock disponible de ${prenda.nombre}.`);
      }
    }
  
    generarTotal() {
      let total = 0;
      for (let i = 0; i < this.prendas.length; i++) {
        total += this.prendas[i].precio;
      }
      return total;
    }
  
    mostrarListado() {
      if (this.prendas.length === 0) {
        alert("No agregaste productos al carrito.");
      } else {
        let mensaje = "Productos en el carrito:\n";
        for (let i = 0; i < this.prendas.length; i++) {
          const prenda = this.prendas[i];
          mensaje += `- ${prenda.nombre} - $${prenda.precio}\n`;
        }
        mensaje += `Total: $${this.generarTotal()}`;
        alert(mensaje);
      }
    }
  }
  
  
  const CatalogoDePrendas = [
    new Prenda("Remera Blanca", 3500, 3),
    new Prenda("Pantalón Jeans", 7200, 2),
    new Prenda("Campera Negra", 9800, 1),
  ];
  
  
  function mostrarCatalogo() {
    let mensajeCatalogo = "Catálogo de prendas:\n";
    for (let i = 0; i < CatalogoDePrendas.length; i++) {
      const prenda = CatalogoDePrendas[i];
      mensajeCatalogo += `${i + 1}. ${prenda.nombre} - $${prenda.precio} - Stock: ${prenda.stock}\n`;
    }
    
    mensajeCatalogo += `${CatalogoDePrendas.length + 1}. Finalizar compra`;
  
    return prompt(mensajeCatalogo);
  }
  
  
  const carrito = new Carrito();
  
  
  let seguirComprando = true;
  while (seguirComprando) {
    let opcion = mostrarCatalogo();
  
    
    if (opcion === null || parseInt(opcion) === CatalogoDePrendas.length + 1) {
      seguirComprando = false;
    } else {
      let index = parseInt(opcion) - 1;
  
      
      if (index >= 0 && index < CatalogoDePrendas.length) {
        carrito.agregarPrenda(CatalogoDePrendas[index]);
      } else {
        alert("Opción inválida.");
      }
    }
  }
  
  
  carrito.mostrarListado();
  